#!/bin/bash
g09 Mol37.gjf &&
g09 Mol41.gjf &
